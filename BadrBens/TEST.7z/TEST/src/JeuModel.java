import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;

public class JeuModel {

	static final int N = 4;
	private final List<JButton> list = new ArrayList<JButton>();
	public List<JButton> getList() {
		return list;
	}

}
