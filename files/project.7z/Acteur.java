import java.util.Date;

public class Acteur extends Personne {

	private String sepcialite;
	private Date dateAffectation;

	public String getSepcialite() {
		return sepcialite;
	}

	public void setSepcialite(String sepcialite) {
		this.sepcialite = sepcialite;
	}

	public Date getDateAffectation() {
		return dateAffectation;
	}

	public void setDateAffectation(Date dateAffectation) {
		this.dateAffectation = dateAffectation;
	}

}
