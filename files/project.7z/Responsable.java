import java.util.List;

public class Responsable extends Personne {

	private List<Spectacle> spectacles;

	public List<Spectacle> getSpectacles() {
		return spectacles;
	}

	public void setSpectacles(List<Spectacle> spectacles) {
		this.spectacles = spectacles;
	}

}
